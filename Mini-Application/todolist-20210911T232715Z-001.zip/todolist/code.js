 var add = document.getElementById('addInput');
  var newItem = document.getElementById('doInput');
  var clear = document.getElementById('clear');
  var list = document.getElementById('list');
  var listers = document.querySelector('#list');
  listItem = document.getElementsByTagName('li');
  var todo;
  add.addEventListener('click', addItemToList);
  newItem.addEventListener('keydown', function(e) {
    if (e.code === "Enter") {
      addItemToList();
    }
  });

  function addItemToList() {
    if (newItem.value != '') {
      todo = '<li>' + newItem.value + '</li>';
      list.innerHTML += todo;
      save();
      newItem.value = ' '
    } else {
      return
    }
  };
  listers.addEventListener('click', (e) => {
    var h = e.target;
    if (h.classList.contains('checked')) {
      h.parentNode.removeChild(h);
      save();
    } else {
      h.classList.add('checked');
      save()
    }
  }, false);
  clear.addEventListener('click', () => {
    list.innerHTML = ' ';
    save()
  });

  function save() {
    window.localStorage.myitems = list.innerHTML;
  };

  function restore() {
    if (window.localStorage !== null) {
      list.innerHTML = window.localStorage.myitems;
    }
  };
  restore();